package gb.lession6_9;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class TestGame extends JFrame {

    private static TestGame test_game;
    private static long last_frame_time;
    private static Image background;
    private static Image gameover;
    private static Image heart;
    private static int score;
    private static float drop_left = 50;
    private static float drop_top = -150;
    private static float drop_v = 150;


    public static void main(String[] args) throws IOException{
	// TestGame - code of Window:
        //images:
        background = ImageIO.read(TestGame.class.getResourceAsStream("background.png"));
        heart = ImageIO.read(TestGame.class.getResourceAsStream("heart.png"));
        gameover = ImageIO.read(TestGame.class.getResourceAsStream("gameover.png"));
        test_game = new TestGame();
        test_game.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //
        test_game.setLocation(40, 40);
        // Coordinates
        test_game.setSize(1024, 600);
        // Window properties
        test_game.setResizable(false);
        last_frame_time = System.nanoTime();
        // Static Window (because - false)
        GameField game_field = new GameField();
        game_field.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int x =  e.getX();
                int y = e.getY();
                float drop_right = drop_left + heart.getWidth(null);
                float drop_bottom = drop_top + heart.getHeight(null);
                boolean is_drop = x >= drop_left && x <= drop_right && y >= drop_top && y <= drop_bottom;
                    if (is_drop) {
                        drop_top = - 150;
                        drop_left = (int) (Math.random() * (game_field.getWidth() - heart.getWidth(null)));
                        drop_v = drop_v + 10;
                        score++;
                        test_game.setTitle("Score:" + score);
                    }
            }
        });
        test_game.add(game_field);
        test_game.setVisible(true);
    }

    public static void onRepaint(Graphics g) {
        long current_time = System.nanoTime();
        float delta_time = (current_time - last_frame_time) * 0.000000001f;
        last_frame_time = current_time;

        drop_top = drop_top + drop_v * delta_time;

        g.drawImage(background, 0, 0, null);
        g.drawImage(heart, (int) drop_left, (int)drop_top, null);

        if (drop_top > test_game.getHeight())g.drawImage(gameover,320, 240, null);
    }

    public static void setDrop(Image heart) {
        TestGame.heart = heart;
    }

    private static class GameField extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            onRepaint(g);
            repaint();
        }

    }
}
